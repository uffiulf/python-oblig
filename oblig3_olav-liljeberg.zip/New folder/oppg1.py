


student = { 
    "first name" : "Ola", 
    "last name" : "Nordmann",
    "favourite course" : "Programmering 1" 
} 


print(student["first name"],student["last name"])


student["favourite course"]="ITF10219 Programmering 1"

student.update({"age":"11"})

