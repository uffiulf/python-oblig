


def print_list(yup):
    for x in yup:
        print(x)
    



Gordon_ramsey = ["kylling biiirrrianii","flesk og duppe", "taco (ekte taco og ikke den shiten de lager her!)"]

print_list(Gordon_ramsey)