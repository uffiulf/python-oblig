


def volume_kalkis():
    a = input("L: ")
    b = input("B: ")
    c = input("H: ")
    a = int(a)
    b = int(b)
    c = int(c)
    d = a*b*c
    print(d)


for x in range(3):
    volume_kalkis()